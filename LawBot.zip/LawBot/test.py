import tkinter as tk
from tkinter import scrolledtext
from PIL import Image, ImageTk

import pandas as pd

class ChatBotGUI:
    def __init__(self, master):
        self.master = master
        master.title("ChatBot")
        master.geometry("1350x768")

        # Load background image
        self.background_image = Image.open('images/Register.png')  # Adjust the file path as needed
        self.background_photo = ImageTk.PhotoImage(self.background_image)
        self.background_label = tk.Label(master, image=self.background_photo)
        self.background_label.place(x=0, y=0, relwidth=1, relheight=1)

        # Create a frame for the chat components
        self.chat_frame = tk.Frame(master, bg='white', bd=5)
        self.chat_frame.place(x=100, y=50, width=950, height=550)

        self.chatbox = scrolledtext.ScrolledText(self.chat_frame, width=80, height=20, font=("Arial", 14))
        self.chatbox.place(x=10, y=10)

        # Entry, Label, and Button outside the chatbox
        self.user_entry = tk.Entry(master, width=40, font=("Arial", 18), bg='grey')
        self.user_entry.place(x=170, y=620)

        self.entry_label = tk.Label(master, text="User:", font=("Arial", 18), fg='blue')
        self.entry_label.place(x=100, y=620)

        self.send_button = tk.Button(master, text="Send", command=self.send_message, font=("Arial", 14))
        self.send_button.place(x=730, y=620)

        self.load_dataset()
        self.chatbot_response("ChatBot: Hello! How can I assist you today?", color='red')
    
    def load_dataset(self):
        # Load the LawSet dataset
        self.laws_dataset = pd.read_csv('LawSet.csv')  # Adjust the file path as needed
    
    def send_message(self):
        user_input = self.user_entry.get()
        if user_input:
            self.chatbox.insert(tk.END, f"User: {user_input}\n", 'user_message')
            self.user_entry.delete(0, tk.END)

            # Get chatbot response based on user input
            chatbot_response = self.get_chatbot_response(user_input)

            self.chatbot_response(f"ChatBot: {chatbot_response}", color='red')

    def chatbot_response(self, message, color='black'):
        self.chatbox.insert(tk.END, message + "\n", color)
        self.chatbox.yview(tk.END)

    def get_chatbot_response(self, user_query):
        user_query = user_query.lower()
        
        # Simple rule-based logic to find a response from the dataset
        for index, row in self.laws_dataset.iterrows():
            question = str(row['Questions']).lower()
            if user_query in question:
                return str(row['Answers'])

        # If no match found, provide a default response
        return "I'm sorry, I couldn't find information on that topic."

if __name__ == "__main__":
    root = tk.Tk()
    chatbot_gui = ChatBotGUI(root)
    root.mainloop()
