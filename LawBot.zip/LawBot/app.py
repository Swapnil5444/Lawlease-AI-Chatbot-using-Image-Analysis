from flask import Flask, render_template, request, redirect, url_for, flash, make_response, jsonify
import pandas as pd
import hashlib
import csv  # Add this import

app = Flask(__name__)
app.secret_key = 'secret_key'  # Change this to a more secure key in production

USERS_CSV = 'users.csv'
LAWSET_CSV = 'LawSet.csv'  # Add the path to your LawSet.csv file

# Hash password function
def hash_password(password):
    return hashlib.sha256(password.encode('utf-8')).hexdigest()

# Get user from CSV file
def get_user(username):
    users_df = pd.read_csv(USERS_CSV)
    for index, row in users_df.iterrows():
        if row['username'] == username:
            return row.to_dict()
    return None

# Save user to CSV file
def save_user(username, password):
    with open(USERS_CSV, mode='a', newline='') as csvfile:
        fieldnames = ['username', 'password']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writerow({'username': username, 'password': hash_password(password)})

# Verify password function
def verify_password(username, password):
    user = get_user(username)
    if user:
        return user['password'] == hash_password(password)
    return False

# Load the LawSet dataset
laws_dataset = pd.read_csv(LAWSET_CSV)

# Routes

@app.route('/')
def index():
    # Check if the user is logged in
    username = request.cookies.get('username')
    if not username:
        # If not logged in, redirect to login page
        return redirect(url_for('login'))

    return render_template('index.html', username=username)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if verify_password(username, password):
            flash('Login successful!', 'success')

            # Set a cookie to indicate that the user is logged in
            response = make_response(redirect(url_for('index')))
            response.set_cookie('username', username)

            return response
        else:
            flash('Incorrect username or password. Login failed.', 'error')
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        save_user(username, password)
        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/get_response', methods=['POST'])
def get_response():
    user_query = request.form['user_query']
    chatbot_response = get_chatbot_response(user_query)
    return jsonify({'response': chatbot_response})

def get_chatbot_response(user_query):
    user_query = user_query.lower()

    # Simple rule-based logic to find a response from the dataset
    for index, row in laws_dataset.iterrows():
        question = str(row['Questions']).lower()
        if user_query in question:
            return str(row['Answers'])

    # If no match found, provide a default response
    return "I'm sorry, I couldn't find information on that topic."

if __name__ == '__main__':
    app.run(debug=True)
